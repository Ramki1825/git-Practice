define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for btnLogout **/
    AS_Button_b92275a616c9494e82aadadb211e7b55: function AS_Button_b92275a616c9494e82aadadb211e7b55(eventobject) {
        var self = this;

        function _ide_onClick_a4d846ed1cad4953846fb87354105557_Callback() {
            // this.view.flxHamberger.flxLogOut.setVisibility(false);
            // this.view.flxHamberger.flxLogin.setVisibility(true);
            this.view.flxHamberger.flxLogin.btnLogin.setVisibility(true);
            this.view.flxHamberger.flxLogin.btnLogout.setVisibility(false);
            this.view.flxHamberger.flxLogin.btnMyAccount.setVisibility(false);
            this.view.flxHamberger.flxLogin.btnRegistration.setVisibility(true);
        }
        self.view.flxHamberger.animate(
        voltmx.ui.createAnimation({
            "100": {
                "left": "390dp",
                "stepConfig": {
                    "timingFunction": voltmx.anim.EASE
                }
            }
        }), {
            "delay": 0,
            "iterationCount": 1,
            "fillMode": voltmx.anim.FILL_MODE_FORWARDS,
            "duration": 0.25
        }, {
            "animationEnd": _ide_onClick_a4d846ed1cad4953846fb87354105557_Callback
        });
    },
    /** onClick defined for btnMyAccount **/
    AS_Button_d1599ca33e3f44ec8f1113c906bb9bfa: function AS_Button_d1599ca33e3f44ec8f1113c906bb9bfa(eventobject) {
        var self = this;

        function _ide_onClick_e2576631114740e296816c6dcffa6d87_Callback() {
            voltmx.application.destroyForm("frmIndividualReg");
            // Navigate to another form after successful registration
            var navigationManager = new voltmx.mvc.Navigation("frmIndividualReg");
            navigationManager.navigate(); // Navigate to frmIndividualReg form
        }
        self.view.flxHamberger.animate(
        voltmx.ui.createAnimation({
            "100": {
                "left": "390dp",
                "stepConfig": {
                    "timingFunction": voltmx.anim.EASE
                }
            }
        }), {
            "delay": 0,
            "iterationCount": 1,
            "fillMode": voltmx.anim.FILL_MODE_FORWARDS,
            "duration": 0.25
        }, {
            "animationEnd": _ide_onClick_e2576631114740e296816c6dcffa6d87_Callback
        });
    },
    /** onClick defined for btnRegistration **/
    AS_Button_g040b760831c4473ab503ee6b034b4fa: function AS_Button_g040b760831c4473ab503ee6b034b4fa(eventobject) {
        var self = this;

        function MOVE_ACTION_d4bef6d745014521b0c46876b1371414_Callback() {
            var ntf;
            if (kony.store.getItem("isLogin") === "Y") {
                //    flxLogReg.btnLogin.text === "Login"){
                voltmx.application.destroyForm("frmMyProfile");
                ntf = new voltmx.mvc.Navigation("frmMyProfile");
                ntf.navigate();
            } else {
                kony.store.setItem("isLogin", "N");
                voltmx.application.destroyForm("frmIndividualReg");
                ntf = new voltmx.mvc.Navigation("frmIndividualReg");
                ntf.navigate();
            }
            // voltmx.application.destroyForm("frmIndividualReg");
            // // Navigate to another form after successful registration
            //      var navigationManager = new voltmx.mvc.Navigation("frmIndividualReg"); 
            //      navigationManager.navigate(); // Navigate to frmIndividualReg form
        }
        self.view.flxHamberger.animate(
        voltmx.ui.createAnimation({
            "100": {
                "left": "390dp",
                "stepConfig": {
                    "timingFunction": voltmx.anim.EASE
                }
            }
        }), {
            "delay": 0,
            "iterationCount": 1,
            "fillMode": voltmx.anim.FILL_MODE_FORWARDS,
            "duration": 0.25
        }, {
            "animationEnd": MOVE_ACTION_d4bef6d745014521b0c46876b1371414_Callback
        });
    },
    /** onClick defined for btnLogin **/
    AS_Button_i9c5e1ff18fd4518b4ef820caf848fb5: function AS_Button_i9c5e1ff18fd4518b4ef820caf848fb5(eventobject) {
        var self = this;

        function MOVE_ACTION_b00abffef3fd4783b35036e4fbffb7de_Callback() {
            var ntf;
            if (kony.store.getItem("isLogin") !== "Y") {
                //    flxLogReg.btnLogin.text === "Login"){
                voltmx.application.destroyForm("frmLogin");
                ntf = new voltmx.mvc.Navigation("frmLogin");
                ntf.navigate();
            } else {
                kony.store.setItem("isLogin", "N");
                voltmx.application.destroyForm("frmHome");
                ntf = new voltmx.mvc.Navigation("frmHome");
                ntf.navigate();
            }
        }
        self.view.flxHamberger.animate(
        voltmx.ui.createAnimation({
            "100": {
                "left": "390dp",
                "stepConfig": {
                    "timingFunction": voltmx.anim.EASE
                }
            }
        }), {
            "delay": 0,
            "iterationCount": 1,
            "fillMode": voltmx.anim.FILL_MODE_FORWARDS,
            "duration": 0.25
        }, {
            "animationEnd": MOVE_ACTION_b00abffef3fd4783b35036e4fbffb7de_Callback
        });
    },
    /** onTouchEnd defined for flx3 **/
    AS_FlexContainer_a7a0eff850064e31b8dac38c01f8f7e5: function AS_FlexContainer_a7a0eff850064e31b8dac38c01f8f7e5(eventobject, x, y) {
        var self = this;

        function MOVE_ACTION_ad61fa21f2a94e4e8f54ae1fce25a629_Callback() {
            voltmx.application.destroyForm("frmDirectSale");
            // Navigate to another form after successful registration
            var navigationManager = new voltmx.mvc.Navigation("frmDirectSale");
            navigationManager.navigate(); // Navigate to frmDirectSale form
        }
        self.view.flxHamberger.animate(
        voltmx.ui.createAnimation({
            "100": {
                "left": "390dp",
                "stepConfig": {
                    "timingFunction": voltmx.anim.EASE
                }
            }
        }), {
            "delay": 0,
            "iterationCount": 1,
            "fillMode": voltmx.anim.FILL_MODE_FORWARDS,
            "duration": 0.25
        }, {
            "animationEnd": MOVE_ACTION_ad61fa21f2a94e4e8f54ae1fce25a629_Callback
        });
    },
    /** onClick defined for flx6 **/
    AS_FlexContainer_bba122f03d6b4db3817af544c3057504: function AS_FlexContainer_bba122f03d6b4db3817af544c3057504(eventobject) {
        var self = this;
        // Navigate to another form after successful registration
        var navigationManager = new voltmx.mvc.Navigation("frmContactUs");
        navigationManager.navigate(); // Navigate to frmHome form
    },
    /** onTouchEnd defined for flx1 **/
    AS_FlexContainer_c285f447fba6431ba08954fc5cffb224: function AS_FlexContainer_c285f447fba6431ba08954fc5cffb224(eventobject, x, y) {
        var self = this;

        function MOVE_ACTION_a425cc0def484c60afafd0f83d5c012c_Callback() {
            voltmx.application.destroyForm("frmHome");
            // Navigate to another form after successful registration
            var navigationManager = new voltmx.mvc.Navigation("frmHome");
            navigationManager.navigate(); // Navigate to frmHome form
        }
        self.view.flxHamberger.animate(
        voltmx.ui.createAnimation({
            "100": {
                "left": "390dp",
                "stepConfig": {
                    "timingFunction": voltmx.anim.EASE
                }
            }
        }), {
            "delay": 0,
            "iterationCount": 1,
            "fillMode": voltmx.anim.FILL_MODE_FORWARDS,
            "duration": 0.25
        }, {
            "animationEnd": MOVE_ACTION_a425cc0def484c60afafd0f83d5c012c_Callback
        });
    },
    /** onTouchEnd defined for flx4 **/
    AS_FlexContainer_d11168405e6c430581e1f82b929e7878: function AS_FlexContainer_d11168405e6c430581e1f82b929e7878(eventobject, x, y) {
        var self = this;

        function MOVE_ACTION_a1869cfad66b42d6977baa5113375fce_Callback() {
            voltmx.application.destroyForm("frmAuctionGuide");
            // Navigate to another form after successful registration
            var navigationManager = new voltmx.mvc.Navigation("frmAuctionGuide");
            navigationManager.navigate(); // Navigate to frmAuctionGuide form
        }
        self.view.flxHamberger.animate(
        voltmx.ui.createAnimation({
            "100": {
                "left": "390dp",
                "stepConfig": {
                    "timingFunction": voltmx.anim.EASE
                }
            }
        }), {
            "delay": 0,
            "iterationCount": 1,
            "fillMode": voltmx.anim.FILL_MODE_FORWARDS,
            "duration": 0.25
        }, {
            "animationEnd": MOVE_ACTION_a1869cfad66b42d6977baa5113375fce_Callback
        });
    },
    /** onTouchEnd defined for flx5 **/
    AS_FlexContainer_i8c12fdc08b04cb798ff7992171cc378: function AS_FlexContainer_i8c12fdc08b04cb798ff7992171cc378(eventobject, x, y) {
        var self = this;

        function MOVE_ACTION_e3b37dad7bb14bde947aa2b7496a731e_Callback() {
            voltmx.application.destroyForm("frmAboutCompany");
            // Navigate to another form after successful registration
            var navigationManager = new voltmx.mvc.Navigation("frmAboutCompany");
            navigationManager.navigate(); // Navigate to frmAboutCompany form
        }
        self.view.flxHamberger.animate(
        voltmx.ui.createAnimation({
            "100": {
                "left": "390dp",
                "stepConfig": {
                    "timingFunction": voltmx.anim.EASE
                }
            }
        }), {
            "delay": 0,
            "iterationCount": 1,
            "fillMode": voltmx.anim.FILL_MODE_FORWARDS,
            "duration": 0.25
        }, {
            "animationEnd": MOVE_ACTION_e3b37dad7bb14bde947aa2b7496a731e_Callback
        });
    },
    /** onTouchEnd defined for flx2 **/
    AS_FlexContainer_j263351f55d34e8a84b2105092acc246: function AS_FlexContainer_j263351f55d34e8a84b2105092acc246(eventobject, x, y) {
        var self = this;

        function MOVE_ACTION_df61400907a04174a72953108b6f23b4_Callback() {
            voltmx.application.destroyForm("frmOnlineTest");
            // Navigate to another form after successful registration
            var navigationManager = new voltmx.mvc.Navigation("frmOnlineTest");
            navigationManager.navigate(); // Navigate to frmOnlineAuctionHome form
        }
        self.view.flxHamberger.animate(
        voltmx.ui.createAnimation({
            "100": {
                "left": "390dp",
                "stepConfig": {
                    "timingFunction": voltmx.anim.EASE
                }
            }
        }), {
            "delay": 0,
            "iterationCount": 1,
            "fillMode": voltmx.anim.FILL_MODE_FORWARDS,
            "duration": 0.25
        }, {
            "animationEnd": MOVE_ACTION_df61400907a04174a72953108b6f23b4_Callback
        });
    },
    /** onTouchEnd defined for flx6 **/
    AS_FlexContainer_ja24bd78ad0a4462a3e9b9cad9985780: function AS_FlexContainer_ja24bd78ad0a4462a3e9b9cad9985780(eventobject, x, y) {
        var self = this;

        function MOVE_ACTION_hedf6d39cecc40f08c180fe0173be485_Callback() {
            voltmx.application.destroyForm("frmContactUs");
            // Navigate to another form after successful registration
            var navigationManager = new voltmx.mvc.Navigation("frmContactUs");
            navigationManager.navigate(); // Navigate to frmAboutCompany form
        }
        self.view.flxHamberger.animate(
        voltmx.ui.createAnimation({
            "100": {
                "left": "390dp",
                "stepConfig": {
                    "timingFunction": voltmx.anim.EASE
                }
            }
        }), {
            "delay": 0,
            "iterationCount": 1,
            "fillMode": voltmx.anim.FILL_MODE_FORWARDS,
            "duration": 0.25
        }, {
            "animationEnd": MOVE_ACTION_hedf6d39cecc40f08c180fe0173be485_Callback
        });
    },
    /** onTouchEnd defined for CopyimageRA0b12754ce40284b **/
    AS_Image_f677ee2c5e824f8ba2100f4372df21f8: function AS_Image_f677ee2c5e824f8ba2100f4372df21f8(eventobject, x, y) {
        var self = this;

        function MOVE_ACTION_d91d70db003f4bd0978f4b98990377d0_Callback() {}
        self.view.flxHamberger.animate(
        voltmx.ui.createAnimation({
            "100": {
                "left": "0dp",
                "stepConfig": {
                    "timingFunction": voltmx.anim.EASE
                }
            }
        }), {
            "delay": 0,
            "iterationCount": 1,
            "fillMode": voltmx.anim.FILL_MODE_FORWARDS,
            "duration": 0.25
        }, {
            "animationEnd": MOVE_ACTION_d91d70db003f4bd0978f4b98990377d0_Callback
        });
    },
    /** onTouchEnd defined for CopyimageRA0b5c33e808cff4e **/
    AS_Image_j2900d49ecdb42f487120cba0ef33da8: function AS_Image_j2900d49ecdb42f487120cba0ef33da8(eventobject, x, y) {
        var self = this;

        function MOVE_ACTION_fcd1903de6774334a4d506550bb8d611_Callback() {}
        self.view.flxHamberger.animate(
        voltmx.ui.createAnimation({
            "100": {
                "left": "100%",
                "stepConfig": {
                    "timingFunction": voltmx.anim.EASE
                }
            }
        }), {
            "delay": 0,
            "iterationCount": 1,
            "fillMode": voltmx.anim.FILL_MODE_FORWARDS,
            "duration": 0.25
        }, {
            "animationEnd": MOVE_ACTION_fcd1903de6774334a4d506550bb8d611_Callback
        });
    }
});