define(function() {
    return {
        // Function to get Language
        getLangLabelText: function() {
           var lan = this.view.flxHamberger.flxLogin.btnChangeLang.text;
            return lan;
        }
    };
});
