define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for flx4 **/
    AS_FlexContainer_e8ed9f7b44994990bcad2f770ae27053: function AS_FlexContainer_e8ed9f7b44994990bcad2f770ae27053(eventobject) {
        var self = this;
        var ntf = new voltmx.mvc.Navigation("frmCarImages");
        ntf.navigate({
            "img4_base64": self.view.img4.base64,
            "_meta_": {
                "eventName": "onClick",
                "widgetId": "flx4"
            }
        });
    },
    /** onClick defined for flx2 **/
    AS_FlexContainer_ff93e2bc130d4f89889e7511f2a9ac18: function AS_FlexContainer_ff93e2bc130d4f89889e7511f2a9ac18(eventobject) {
        var self = this;
        var ntf = new voltmx.mvc.Navigation("frmCarImages");
        ntf.navigate({
            "img2_base64": self.view.img2.base64,
            "_meta_": {
                "eventName": "onClick",
                "widgetId": "flx2"
            }
        });
    },
    /** onClick defined for flx3 **/
    AS_FlexContainer_iea4e440d0b34ccdb72b062dd0fcf39a: function AS_FlexContainer_iea4e440d0b34ccdb72b062dd0fcf39a(eventobject) {
        var self = this;
        var ntf = new voltmx.mvc.Navigation("frmCarImages");
        ntf.navigate({
            "img3_base64": self.view.img3.base64,
            "_meta_": {
                "eventName": "onClick",
                "widgetId": "flx3"
            }
        });
    },
    /** onClick defined for flx1 **/
    AS_FlexContainer_j6748b6af47e4aea88f868329bd1fc3d: function AS_FlexContainer_j6748b6af47e4aea88f868329bd1fc3d(eventobject) {
        var self = this;
        var ntf = new voltmx.mvc.Navigation("frmCarImages");
        ntf.navigate({
            "img1_base64": self.view.img1.base64,
            "_meta_": {
                "eventName": "onClick",
                "widgetId": "flx1"
            }
        });
    },
    /** postShow defined for frmCarDetails **/
    AS_Form_ceb4059fe87144029a904fc08752b4cd: function AS_Form_ceb4059fe87144029a904fc08752b4cd(eventobject) {
        var self = this;
        var isLog = kony.store.getItem("isLogin");
        if (isLog === "Y") {
            this.view.flxMain.Head.flxHamberger.flxLogin.btnRegistration.setVisibility(false);
            this.view.flxMain.Head.flxHamberger.flxLogin.btnLogin.setVisibility(false);
            this.view.flxMain.Head.flxHamberger.flxLogin.btnLogout.setVisibility(true);
            this.view.flxMain.Head.flxHamberger.flxLogin.btnMyAccount.setVisibility(true);
            //   this.view.flxMain.Head.flxHamberger.flxLogin.btnLogin.text="Logout";
            //  this.view.flxMain.Head.flxHamberger.flxLogin.btnRegistration.text="My Account";
        } else {
            this.view.flxMain.Head.flxHamberger.flxLogin.btnLogout.setVisibility(false);
            this.view.flxMain.Head.flxHamberger.flxLogin.btnMyAccount.setVisibility(false);
            this.view.flxMain.Head.flxHamberger.flxLogin.btnRegistration.setVisibility(true);
            this.view.flxMain.Head.flxHamberger.flxLogin.btnLogin.setVisibility(true);
            //    this.view.flxMain.Head.flxHamberger.flxLogin.btnLogin.text="Login";
            //    this.view.flxMain.Head.flxHamberger.flxLogin.btnRegistration.text="Register Now";
        }
    },
    /** preShow defined for frmCarDetails **/
    AS_Form_g23358d883d2484193913c7a9ba2c1c3: function AS_Form_g23358d883d2484193913c7a9ba2c1c3(eventobject) {
        var self = this;
        return self.OnNavigate.call(this, null);
    }
});