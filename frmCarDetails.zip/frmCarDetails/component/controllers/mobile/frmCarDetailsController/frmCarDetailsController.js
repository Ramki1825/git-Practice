define({
  OnNavigate: function (eventobject) {
    var self = this;
    if (this.getPreviousForm() === "frmOnlineTest") {
      var carID = this.navigationContext.id;  
      var requestParams = {
        "serviceID"  : "Vehical_Info$NewOperation",
        "id"         : carID,  // Use the carID received from navigation context
        "httpheaders": {},
        "httpconfig" : {}
      };

      // Invoke the service and pass the callback function
      mfintegrationsecureinvokerasync(requestParams, "Vehical_Info", "NewOperation", function(status, responseData) {
        self.onDataReceived(status, responseData);
      });
    }
  },

  // Callback function to process the response data
  onDataReceived: function(status, responseData) {
    var self = this;
    
    // Check if the response data is valid and contains the necessary information
    if (!responseData || !responseData.data || responseData.data.length === 0) {
      alert("No valid data received.");
      return;
    }

    // Extract the first car object from the array
    var car = responseData.data[0];

    // Set dynamic values based on car object properties with fallback to "N/A"
    self.view.lblCarName.text = car.model || "N/A";
    self.view.lblId.text = car.id ? voltmx.visualizer.toString(car.id) : "N/A";
    self.view.lblPrice.text = "20000";
    self.view.lblTimer.text = "7D 6H 3M 54S";
    self.view.btnLike.text = "🤍";  // Static button text
    self.view.btnAutoBid.text = "⚡";  // Static button text
    self.view.lblLocationName.text = "New York"; 
    self.view.lblModelYearValue.text = car.year ? voltmx.visualizer.toString(car.year) : "N/A";
    self.view.lblFuelValue.text = "Petrol";
    self.view.lblTransmissionValue.text = "Automatic";
    self.view.lblColorValue.text = car.color || "N/A";
    self.view.lblDoorsValue.text = "4"; 
    self.view.lblFeatureIdValue.text = car.id ? voltmx.visualizer.toString(car.id) : "N/A";
    self.view.lblFeatureOwnerValue.text = car.owner || "N/A";
    self.view.lblFeatureModelValue.text = car.model || "N/A";
    self.view.lblFeatureLicenceValue.text = car.license_plate || "N/A";
    self.view.lblFeatureColorValue.text = car.color || "N/A";
    self.view.lblFeatureYearValue.text = car.year ? voltmx.visualizer.toString(car.year) : "N/A";
    self.view.lblFeatureTypeValue.text = car.type || "N/A";
    self.view.lblFeatureMakeValue.text = car.make || "N/A";
    self.view.lblFeatureStatusValue.text = car.status || "N/A";
    self.view.lblFeatureMilageValue.text = car.mileage ? voltmx.visualizer.toString(car.mileage) : "N/A";
    self.view.lblCondition.text = car.status || "N/A";
    self.view.lblMilage.text = car.mileage ? voltmx.visualizer.toString(car.mileage) : "N/A";
    self.view.lblAvgkm.text = (voltmx.visualizer.toString(car.mileage) / 4);
   
    // Handle base64 images safely: Iterate over the array and assign values dynamically
    if (car.base64_images && Array.isArray(car.base64_images)) {
      // Ensure we don't go out of bounds for the array of images
      for (var i = 0; i < car.base64_images.length && i < 4; i++) {
        self.view["img" + (i + 1)].base64 = car.base64_images[i] || ""; // Assign base64 image or empty string if not available
      }
    } else {
      // If no base64 images or empty array, set default empty images
      for (var i = 1; i <= 4; i++) {
        self.view["img" + i].base64 = "";  // Set empty base64 string if images are not available
      }
    }
  }
});
